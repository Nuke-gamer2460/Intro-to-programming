var scores = {
  nick: 0,
  philly: 0
};

// Increase Philly's score by 100
scores.philly += 100;

// Increase Nick's score by 90
scores.nick += 90;

// Show scores
scores;
// { nick: 90, philly: 100 }
