# JavaScriptForKidsSolutions
Solutions to programming challenges from the [JavaScript for Kids A Playful Introduction to Programming](https://www.nostarch.com/javascriptforkids) book by [Nick Morgan](https://github.com/skilldrick)
